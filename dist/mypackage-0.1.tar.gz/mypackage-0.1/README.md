# This library was created to demonstrate how to publish your own Python package

This Python package returns the top-n items in an array, in descending order.

## Installation

Use the package manager [pip] to install mypackage.

```bash
pip install mypackage
```
## Usage

import numpy


## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License

MIT
